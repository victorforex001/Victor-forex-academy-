Victor Forex Academy website starter

Files: index.html, style.css, script.js, logo.png
WhatsApp: +234 810 603 5430

Course prices are starter values of N30,000 each and are easy to edit in index.html.
Training prices used from the requested academy pricing: Online N30,000, Physical N65,000, 1-on-1 N100,000.
Open index.html in a browser to preview the website.
